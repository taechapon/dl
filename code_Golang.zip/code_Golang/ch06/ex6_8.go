package main

import (
	"fmt"
)

func main() {
	i := 1
	total_amount := 0.0
	var stuff_num int
	var price float64

	fmt.Print("How many stuff do you buy? : ")
	fmt.Scan(&stuff_num)

	for i <= stuff_num {
		fmt.Printf("Price of stuff%d is ", i)
		fmt.Scan(&price)
		total_amount = total_amount + price
		i++
	}
	fmt.Printf("Total amount of your stuff is %.2f", total_amount)
}