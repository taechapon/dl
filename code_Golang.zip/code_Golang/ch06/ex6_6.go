package main

import (
	"fmt"
)

func main() {
	var month string

	fmt.Print("Please enter month (for example : Jan, Feb) : ")
	fmt.Scan(&month)

	switch month {
	case "Jan", "Feb", "Mar":
		fmt.Print("This is Q1 (First quarter)")
	case "Apr", "May", "June":
		fmt.Print("This is Q2 (Second quarter)")
	case "July", "Aug", "Sep":
		fmt.Print("This is Q3 (Third quarter)")
	case "Oct", "Nov", "Dec":
		fmt.Print("This is Q4 (Fourth quarter)")
	default:
		fmt.Printf("%s not found", month)
	}
}