package main

import (
	"fmt"
)

func main() {
	nationality_map := map[string]string{
		"Thailand": "Thai",
		"Vietnam":  "Vietnamese",
		"China":    "Chinese",
		"India":    "Indian",
		"Malaysia": "Malaysian"}
	for _, member := range nationality_map {
		fmt.Println(member)
	}
}
