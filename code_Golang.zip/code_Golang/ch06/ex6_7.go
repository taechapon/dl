package main

import (
	"fmt"
)

func main() {
	i := 10
	max := 50

	for i < max {
		fmt.Println(i)
		i += 10
	}
}