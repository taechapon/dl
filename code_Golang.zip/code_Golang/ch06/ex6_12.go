package main

import (
	"fmt"
)

func main() {
	mystr := "Golang"

	for i, str_member := range mystr {
		fmt.Printf("[Index: %d] : %s\n", i, string(str_member))
	}
}
