package main

import (
	"fmt"
)

func main() {
	var weight, height, bmi float32

	fmt.Print("Please enter weight (kg) : ")
	fmt.Scan(&weight)
	fmt.Print("Please enter height (meter) : ")
	fmt.Scan(&height)

	bmi = weight / (height * height)
	fmt.Printf("Your BMI is %f : ", bmi)

	if bmi < 18.5 {
		fmt.Print("Underweight\n")
	} else if bmi >= 18.5 && bmi < 24.9 {
		fmt.Print("Normal\n")
	} else if bmi >= 25 && bmi < 29.9 {
		fmt.Print("Overweight\n")
	} else if bmi >= 30 && bmi < 34.9 {
		fmt.Print("Obese\n")
	} else {
		fmt.Print("Extremely obese\n")
	}
	fmt.Print("You are whatever you eat, good food good health")
}