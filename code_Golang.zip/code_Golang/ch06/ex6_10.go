package main

import (
	"fmt"
)

func main() {
	for i := 1; i <= 12; i++ {
		fmt.Printf("10*%d \t = \t %d\n", i, 10*i)
	}
}
