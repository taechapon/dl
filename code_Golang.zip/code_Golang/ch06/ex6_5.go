package main

import (
	"fmt"
)

func main() {
	var number int

	fmt.Print("Please enter number 1-5 : ")
	fmt.Scan(&number)

	switch number {
	case 1:
		fmt.Print("One")
	case 2:
		fmt.Print("Two")
	case 3:
		fmt.Print("Three")
	case 4:
		fmt.Print("Four")
	case 5:
		fmt.Print("Five")
	}
}