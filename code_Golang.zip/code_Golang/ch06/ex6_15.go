package main

import (
	"fmt"
)

func main() {
	for i := 2; i <= 3; i++ {
		fmt.Printf("%d times table\n", i)
		for j := 1; j <= 12; j++ {
			fmt.Printf("%d*%d \t = \t %d\n", i, j, i*j)
		}
		fmt.Println()
	}
}