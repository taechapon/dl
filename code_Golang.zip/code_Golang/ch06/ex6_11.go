package main

import (
	"fmt"
)

func main() {
	for i := 10; i >= 0; i -= 2 {
		if i == 6 {
			continue
		} else if i == 2 {
			break
		}
		fmt.Println(i)
	}
}