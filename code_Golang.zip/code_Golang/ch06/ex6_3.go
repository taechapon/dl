package main

import (
	"fmt"
)

func main() {
	var num int

	fmt.Print("Please guess number between 1-10 : ")
	fmt.Scan(&num)

	if num == 8 {
		fmt.Print("You are correct, number is 8\n")
	} else {
		fmt.Printf("You are wrong, number is not %v\n", num)
		fmt.Printf("Please try again later\n")
	}
	fmt.Print("Bye bye, come back to guess number again")
}