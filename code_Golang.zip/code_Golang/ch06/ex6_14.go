package main

import (
	"fmt"
)

func main() {
	mystr_outer := [2]string{"hot", "cold"}
	mystr_inner := [3]string{"chocolate", "coffee", "tea"}
	for _, member_outer := range mystr_outer {
		for _, member_inner := range mystr_inner {
			fmt.Printf("%s %s\n", member_outer, member_inner)
		}
		fmt.Println()
	}
}