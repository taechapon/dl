package main

import (
	"fmt"
)

func main() {
	i := 100
	for {
		fmt.Println(i)
		i -= 20
		if i == 0 {
			break
		}
	}
}