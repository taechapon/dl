package main

import (
	"fmt"
)

func main() {
	a := 20
	b := 10

	fmt.Printf("a is %v\n", a)
	fmt.Printf("b is %v\n", b)

	if a > b {
		fmt.Print("a is greater than b\n")
	}
	fmt.Print("Finish")
}