package main

import (
	"fmt"
)

func main() {
	var num int

	fmt.Print("Please guess number between 1-10 : ")
	fmt.Scan(&num)

	if num == 8 {
		fmt.Print("You are correct, number is 8\n")
	}
	fmt.Print("Bye bye, come back to guess number again")
}