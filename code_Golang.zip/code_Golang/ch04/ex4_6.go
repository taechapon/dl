package main

import (
	"fmt"
)

func main() {
	var a int = 5
	var b int = 2
	var result int = a &^ b

	fmt.Printf("result = %08b\n", result)
}