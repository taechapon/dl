package main

import (
	"fmt"
)

func main() {
	var a int = 20
	var b int = 6

	fmt.Println("a + b = ", a+b)
	fmt.Println("a - b = ", a-b)
	fmt.Println("a * b = ", a*b)
	fmt.Println("a / b = ", a/b)
	fmt.Println("a % b = ", a%b)
	a++
	b--
	fmt.Println("a++ = ", a)
	fmt.Println("b-- = ", b)
}