package main

import (
	"fmt"
)

func main() {
	var x int = 10
	var y int = 2

	fmt.Println("^x is", ^x)
	fmt.Println("^y is", ^y)
}