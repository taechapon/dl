package main

import "fmt"

func main() {
	var var1 int8 = 10
	var var2 int16 = 234
	var var3 int16
	var3 = var1 + var2
	fmt.Println(var3)
}