package main

import (
	"fmt"
)

func main() {
	var a, b, c, d, e int = 100, 100, 100, 100, 100
	var f, g, h, i, j int = 4, 4, 4, 4, 4
	var x int = 15
	var y int = 3

	fmt.Println("a b c d e is 100")
	fmt.Println("f g h i j is 4")
	fmt.Println("x is 15")
	fmt.Println("y is 3")
	a += x
	fmt.Println("a += x ", a)
	b -= x
	fmt.Println("b -= x ", b)
	c *= x
	fmt.Println("c *= x ", c)
	d /= x
	fmt.Println("d /= x ", d)
	e %= x
	fmt.Println("e %= x ", e)
	f &= y
	fmt.Println("f &= y ", f)
	g |= y
	fmt.Println("g |= y ", g)
	h |= y
	fmt.Println("h ^= y ", h)
	i <<= y
	fmt.Println("i <<= y ", i)
	j >>= y
	fmt.Println("j >>= y ", j)
}