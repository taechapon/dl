package main

import (
	"fmt"
	"strconv"
)

func main() {
	s1 := strconv.Itoa(97)
	s2 := strconv.FormatInt(97, 10)
	s3 := strconv.FormatInt(-97, 16)
	s4 := strconv.FormatUint(97, 16)
	fmt.Printf("Itoa() convert 97 to string \"%s\"\n", s1)
	fmt.Printf("FormatInt() convert 97 to string \"%s\" (base 10)\n\n", s2)
	fmt.Printf("FormatInt() convert -97 to string \"%s\" (base 16)\n", s3)
	fmt.Printf("FormatUint() convert 97 to string \"%s\" (base 16)", s4)
}
