package main

import (
	"fmt"
	"strings"
)

func main() {
	str1 := "Love sick"
	str2 := "Love"
	str3 := "Love destiny"
	var s1, s2 string

	fmt.Sscan(str1, &s1, &s2)
	result1 := strings.Compare(s1, str2)
	result2 := strings.Compare(str1, str3)
	result3 := strings.Compare(str2, str3)
	fmt.Printf("Compare %s and %s with Compare() : %d\n", s1, str2, result1)
	fmt.Printf("Compare %s and %s with Compare() : %d\n", str1, str3, result2)
	fmt.Printf("Compare %s and %s with Compare() : %d\n", str2, str3, result3)
}
