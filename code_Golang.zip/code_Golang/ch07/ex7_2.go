package main

import (
	"fmt"
)

func main() {

	//assigning our buffer a message
	message := "I love golang \n Golang programming"

	var s1, s2, s3, s4, s5 string
	var ss1, ss2, ss3, ss4, ss5 string

	fmt.Sscan(message, &s1, &s2, &s3, &s4, &s5)
	fmt.Printf("%s %s %s %s %s", s1, s2, s3, s4, s5)
	fmt.Println()
	fmt.Sscanln(message, &ss1, &ss2, &ss3, &ss4, &ss5)
	fmt.Printf("%s %s %s %s %s", ss1, ss2, ss3, ss4, ss5)
}
