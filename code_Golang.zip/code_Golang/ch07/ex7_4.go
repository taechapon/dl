package main

import (
	"fmt"
	"strconv"
)

func main() {
	var str = "98765"
	number, err := strconv.Atoi(str)
	number2, err := strconv.ParseInt(str, 10, 0)

	if err == nil {
		fmt.Printf("Convert string \"%s\" with Atoi() to int : %d\n", str, number)
		fmt.Printf("Convert string \"%s\" with ParseInt() to int : %d\n", str, number2)
	} else {
		fmt.Printf("Error is %v\n", err)
	}
}
