package main

import (
	"fmt"
	"strings"
)

func main() {
	mystr := "This is Loveis Entertainment"
	mystr1 := "I love golang language"
	mystr4 := "golang"

	str := strings.Replace(mystr, "is", "IS", 3)
	fmt.Println(str)

	str1 := strings.Replace(mystr1, "g", "G", 2)
	fmt.Println(str1)

	str2 := strings.Replace(mystr1, "g", "G", -1)
	fmt.Println(str2)

	str3 := strings.Replace(mystr1, "g", "G", 0)
	fmt.Println(str3)

	str4 := strings.Replace(mystr4, "", "*", 3)
	fmt.Println(str4)
}
