package main

import (
	"fmt"
	"strings"
)

func main() {
	var mystr = "Apple|Banana|Grape|Orange"
	var delimiter = "|"
	var str = strings.Split(mystr, delimiter)
	fmt.Printf("Before split string : %s\n", mystr)
	fmt.Printf("After split string : %s\n", str)
}