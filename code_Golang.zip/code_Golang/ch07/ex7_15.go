package main

import (
	"fmt"
	"strings"
)

func main() {
	fmt.Println(strings.ToUpper("gOlanG"))
	fmt.Println(strings.ToLower("gOlanG"))
}