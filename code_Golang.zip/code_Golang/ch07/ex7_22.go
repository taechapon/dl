package main

import (
	"fmt"
	"strings"
)

func main() {
	mystr := "It is time to go to golang"

	str := strings.ReplaceAll(mystr, "go", "Go")
	str2 := strings.ReplaceAll(str, "to", "TO")
	fmt.Println(str2)
}
