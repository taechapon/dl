package main

import (
	"fmt"
)

func main() {
	str1 := "Love sick"
	str2 := "Love"
	str3 := "Love destiny"
	var s1, s2 string

	fmt.Sscan(str1, &s1, &s2)
	result1 := s1 == str2
	fmt.Printf("%s == %s : %v\n", s1, str2, result1)

	result2 := str1 != str2
	fmt.Printf("%s != %s : %v\n", str1, str2, result2)

	result3 := str3 > str1
	fmt.Printf("%s > %s : %v\n", str3, str1, result3)

	result4 := str2 < str3
	fmt.Printf("%s < %s : %v\n", str2, str3, result4)
}
