package main

import (
	"fmt"
)

func main() {
	str1 := "Apple"
	str2 := "Banana"
	str3 := "Grape"
	str4 := "Orange"
	str1 += ", "
	str2 += ", "
	str3 += ", "
	var str = str1 + str2 + str3 + str4
	var result = "My string is " + str
	fmt.Println(result)
}
