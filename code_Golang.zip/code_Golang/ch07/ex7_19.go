package main

import (
	"fmt"
)

func main() {
	str1 := "Apple"
	str2 := "Banana"
	str3 := "Grape"
	str4 := "Orange"
	mystr := fmt.Sprintf("%s|%s|%s|%s", str1, str2, str3, str4)
	fmt.Println("My string is " + mystr)
}