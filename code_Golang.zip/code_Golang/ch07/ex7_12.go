package main

import (
	"fmt"
	"strconv"
)

func main() {
	s1 := strconv.FormatFloat(26.123456789, 'b', 4, 64)
	fmt.Println(s1)
	s2 := strconv.FormatFloat(26.123456789, 'e', 2, 64)
	fmt.Println(s2)
	s3 := strconv.FormatFloat(26.123456789, 'E', 2, 64)
	fmt.Println(s3)
	s4 := strconv.FormatFloat(26.123456789, 'f', 0, 64)
	fmt.Println(s4)
	s5 := strconv.FormatFloat(26123456.789, 'g', -1, 64)
	fmt.Println(s5)
	s6 := strconv.FormatFloat(26.123456789, 'G', -1, 64)
	fmt.Println(s6)
	s7 := strconv.FormatFloat(26.123456789, 'x', 4, 64)
	fmt.Println(s7)
	s8 := strconv.FormatFloat(26.123456789, 'X', 4, 64)
	fmt.Println(s8)
}