package main

import "fmt"

func main() {
	var dept_id, dept_name, emp string
	var num int

	fmt.Sscanf("82201 : IT Department", "%s : %s Department", &dept_id, &dept_name)
	fmt.Sscanf("520 Employees in IT Department", "%d %s in IT Department", &num, &emp)
	fmt.Printf("Dept Id : %s\n", dept_id)
	fmt.Printf("Dept Name : %s\n", dept_name)
	fmt.Printf("%s : %d\n", emp, num)
}