package main

import "fmt"

func main() {
	mystr := "There are 100 birds.\nThey are red."
	var s1, s2, s3, s4, s5, s6 string
	var i int

	fmt.Sscan(mystr, &s1, &s2, &i, &s3, &s4, &s5, &s6)
	fmt.Printf("From string \"%s\"\n\n", mystr)
	fmt.Println("We can scan string with sscan() like this : ")
	fmt.Printf("String 1 : %s\n", s1)
	fmt.Printf("String 2 : %s\n", s2)
	fmt.Printf("String 3 : %s\n", s3)
	fmt.Printf("String 4 : %s\n", s4)
	fmt.Printf("String 5 : %s\n", s5)
	fmt.Printf("String 6 : %s\n", s6)
	fmt.Printf("%d birds at the zoo, all of them are %s", i, s6)
}
