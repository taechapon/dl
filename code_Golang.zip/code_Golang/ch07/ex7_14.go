package main

import (
	"fmt"
	"strconv"
)

func main() {
	s1 := strconv.FormatBool(true)
	fmt.Printf("type : %T, value : %s\n", s1, s1)
	s2 := strconv.FormatBool(false)
	fmt.Printf("type : %T, value : %s\n", s2, s2)
}
