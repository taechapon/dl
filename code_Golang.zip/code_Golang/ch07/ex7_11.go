package main

import (
	"fmt"
)

func main() {
	var num1, num2, num3 int

	fmt.Print("Please enter 3 numbers : ")
	_, err := fmt.Scanf("%d %d %d", &num1, &num2, &num3)

	if err == nil {
		str := fmt.Sprintf("%d, %d and %d", num1, num2, num3)
		fmt.Printf("Type of str is %T, value is %s\n", str, str)
	} else {
		fmt.Printf("Error is \"%v\"\n", err)
	}
}
