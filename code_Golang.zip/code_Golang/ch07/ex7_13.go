package main

import (
	"fmt"
	"strconv"
)

func main() {
	s1 := strconv.FormatComplex(2+3i, 'b', 2, 64)
	fmt.Println(s1)
	s2 := strconv.FormatComplex(2.5+3i, 'e', 2, 64)
	fmt.Println(s2)
	s3 := strconv.FormatComplex(2.5+3i, 'E', 0, 64)
	fmt.Println(s3)
	s4 := strconv.FormatComplex(2.5+3i, 'f', 0, 64)
	fmt.Println(s4)
	s5 := strconv.FormatComplex(235000+3i, 'g', 1, 64)
	fmt.Println(s5)
	s6 := strconv.FormatComplex(235000+3i, 'G', -1, 64)
	fmt.Println(s6)
	s7 := strconv.FormatComplex(2.5+3i, 'x', 4, 64)
	fmt.Println(s7)
	s8 := strconv.FormatComplex(2.5+3i, 'X', 4, 64)
	fmt.Println(s8)
}
