package main

import (
	"fmt"
	"strings"
)

func main() {
	var mystr = []string{"Apple", "Banana", "Grape", "Orange"}
	var sep = ", "
	var str = strings.Join(mystr, sep)
	fmt.Println(str)

}