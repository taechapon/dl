package main

import (
	"fmt"
	"strconv"
)

func main() {
	var str = "-65535"
	var str2 = "65535"
	number, err := strconv.ParseInt(str, 10, 32)
	number2, err := strconv.ParseUint(str2, 10, 32)

	if err == nil {
		fmt.Printf("Convert string \"%s\" to int32 base 10 : %d\n", str, number)
		fmt.Printf("Convert string \"%s\" to uint32 base 10 : %d\n", str2, number2)
	} else {
		fmt.Printf("Error is %v\n", err)
	}
}