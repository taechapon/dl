package main

import (
	"fmt"
	"strconv"
)

func main() {
	var str = "20-30i"
	num, err := strconv.ParseComplex(str, 64)

	if err == nil {
		fmt.Printf("Convert string \"%s\" to complex : %v\n", str, num)
	} else {
		fmt.Printf("Error is %v\n", err)
	}
}