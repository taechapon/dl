package main

import (
	"fmt"
	"strings"
)

func main() {
	str := "Love at first sight"
	substr1 := "first"
	substr2 := "love"

	b1 := strings.Contains(str, substr1)
	fmt.Printf("There are \"%s\" in \"%s\" : %v\n", substr1, str, b1)

	b2 := strings.Contains(str, substr2)
	fmt.Printf("There are \"%s\" in \"%s\" : %v\n", substr2, str, b2)
}