package main

import (
	"fmt"
	"strconv"
)

func main() {
	str := "3.1415926535"
	num, err := strconv.ParseFloat(str, 32)

	if err == nil {
		fmt.Printf("Convert string \"%s\" to float32 : %f\n", str, num)
	} else {
		fmt.Printf("Error is %v\n", err)
	}

}