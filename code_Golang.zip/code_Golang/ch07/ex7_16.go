package main

import (
	"fmt"
)

func main() {
	str := "Hêllò!"
	var length = len([]rune(str))
	fmt.Printf("Length of the string %s is %d", str, length)
}