package main

import (
	"fmt"
)

func main() {
	var p1 *string
	var p2 *int
	fmt.Printf("%v %v\n", p1, p2)
}