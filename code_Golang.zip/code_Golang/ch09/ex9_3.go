package main

import (
	"fmt"
)

func main() {
	var mystr string = "Hello"
	var p = &mystr

	fmt.Printf("Data type of p is %T\n", p)
	fmt.Printf("p point to mystr, so value is %v", *p)
}
