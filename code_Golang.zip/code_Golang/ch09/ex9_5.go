package main

import (
	"fmt"
)

func main() {
	var num1 int = 10
	var p1 *int
	p1 = &num1
	var p2 **int
	p2 = &p1

	fmt.Printf("Value of num1 is %v\n", num1)
	fmt.Printf("Address of num1 is %v\n\n", &num1)
	fmt.Printf("p1 point to address of num1 at %v, so value is %d\n\n", p1, *p1)

	fmt.Printf("Address of p1 is %v\n", &p1)
	fmt.Printf("p2 point to address of p1 at %v\n", p2)
	fmt.Printf("so value is %d\n\n", **p2)
}