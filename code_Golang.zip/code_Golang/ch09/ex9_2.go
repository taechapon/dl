package main

import (
	"fmt"
)

func main() {
	var mystr string = "Hello"
	var p1 *string = &mystr
	var num1 int = 10
	var p2 *int = &num1

	fmt.Printf("Value of mystr is : %v\n", mystr)
	fmt.Printf("Address of mystr is : %v\n", &mystr)

	fmt.Printf("Value of pointer p1 is : %v\n", p1)
	fmt.Printf("Address of pointer p1 is : %v\n", &p1)
	fmt.Printf("p1 point to mystr, value is : %s\n\n", *p1)

	fmt.Printf("Value of num1 is : %v\n", num1)
	fmt.Printf("Address of num1 is : %v\n", &num1)

	fmt.Printf("Value of pointer p2 is : %v\n", p2)
	fmt.Printf("Address of pointer p2 is : %v\n", &p2)
	fmt.Printf("p2 point to num1, value is : %d\n", *p2)
}
