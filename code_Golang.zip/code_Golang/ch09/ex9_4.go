package main

import (
	"fmt"
)

func main() {
	var num int = 100
	p := &num

	fmt.Printf("Value of num is %v\n", num)
	fmt.Printf("Value of *p is %v\n", *p)
	*p = 500
	fmt.Printf("After change value, *p = 500\n")
	fmt.Printf("Value of num is %v\n", num)
	fmt.Printf("Value of *p is %v\n", *p)
}
