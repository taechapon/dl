package main

import "fmt"

func main() {
	fmt.Print("Please input data (format : name surname age) : ")
	var name, surname string
	var age int
	_, err := fmt.Scanf("%s %s %d", &name, &surname, &age)
	if err == nil {
		fmt.Printf("Name : %s\n", name)
		fmt.Printf("Surname : %s\n", surname)
		fmt.Printf("Age : %d\n", age)
	} else {
		fmt.Printf("Error is \"%v\"\n", err)
	}
}