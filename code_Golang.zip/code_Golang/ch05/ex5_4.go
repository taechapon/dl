package main

import "fmt"

func main() {
	str := "Golang programming"
	str2 := "Golang"
	ch1 := '\''
	ch2 := 'l'
	ch3 := 'o'
	ch4 := 'v'
	ch5 := 'e'
	ch6 := '\''
	fmt.Printf("%s\n", str)
	fmt.Printf("%20s\n", str)
	fmt.Printf("%-10s%-10s\n", str2, str2)
	fmt.Printf("%q\n", str)
	fmt.Printf("\"%s\"\n", str2)
	fmt.Printf("%c%c%c%c%c%c\n", ch1, ch2, ch3, ch4, ch5, ch6)
}