package main

import "fmt"

func main() {
	fmt.Print("Please enter your name, surname, dept : ")
	var name, surname, dept string
	count, err := fmt.Scanln(&name, &surname, &dept)
	fmt.Printf("Number of input is %v", count)
	if err == nil {
		fmt.Printf("\nHello, %v %v [%v]\n", name, surname, dept)
	} else {
		fmt.Printf(", Require 3 input\n")
		fmt.Printf("Error is \"%v\"\n", err)
	}
}