package main

import "fmt"

func main() {
	num := 123.456
	fmt.Println("Print number 123.456 with Printf() function")
	fmt.Printf("%f\t%.2f\n", num, num)
	fmt.Printf("%9.2f\n", num)
	fmt.Printf("%9.f\n", num)
	fmt.Printf("%g\n", num)
	fmt.Printf("%e\n", num)
	fmt.Printf("%x\n", num)
}
