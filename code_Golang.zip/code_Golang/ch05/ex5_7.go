package main

import "fmt"

func main() {
	fmt.Print("Please enter 3 numbers (format : num1,num2,num3) : ")
	var num1, num2, num3, sum int
	_, err := fmt.Scanf("%d,%d,%d", &num1, &num2, &num3)
	sum = num1 + num2 + num3
	if err == nil {
		fmt.Printf("Summary of 3 numbers is %v\n", sum)
	} else {
		fmt.Printf("Error is \"%v\"\n", err)
	}

}