package main

import "fmt"

func main() {
	fmt.Print("Please enter your name : ")
	var name, surname string
	fmt.Scan(&name, &surname)
	fmt.Printf("Hello, %v %v!\n", name, surname)
}
