package main

import "fmt"

func main() {
	name := "Somsri "
	surname := "Jaidee"
	age := 32
	position := "Programmer"
	fmt.Print("Name : ", name)
	fmt.Print(surname)
	fmt.Println()
	fmt.Println("Age : ", age, "years")
	fmt.Println("Position : ", position)
}