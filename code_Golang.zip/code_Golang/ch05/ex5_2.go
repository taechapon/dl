package main

import "fmt"

func main() {
	num := 20
	fmt.Println("Print number 20 with Printf() function")
	fmt.Println("======================================")
	fmt.Printf("%d %+d\n", num, num)
	fmt.Printf("%5d\n", num)
	fmt.Printf("%-5d%-5d\n", num, num)
	fmt.Printf("%05d\n", num)
	fmt.Println("======================================")
	fmt.Printf("Number 20 base 2 is : %b\n", num)
	fmt.Printf("Number 20 base 8 is : %o\n", num)
	fmt.Printf("Number 20 base 16 is : %x\n", num)
	fmt.Printf("Number 20 (unicode format) is : %U\n", num)
	fmt.Printf("Number 70 is character : %c\n", num+50)
}