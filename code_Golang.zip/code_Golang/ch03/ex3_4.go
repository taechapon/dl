package main

import (
	"fmt"
)

// ประกาศตัวแปร name ด้วย := ไว้ภายนอกฟังก์ชั่น main ซึ่งการประกาศแบบนี้ผิด
name := "Orapin"

func main() {
	fmt.Println("Hello World! ", name)
}
