package main

import (
	"fmt"
)

func main() {
	var myFloat = 58220.69958777

	fmt.Printf("Type of myFloat is %T \n", myFloat)
	fmt.Printf("Value of myFloat is %v (%.2f)\n", myFloat, myFloat)
}