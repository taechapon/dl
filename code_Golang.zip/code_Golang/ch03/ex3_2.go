package main

import (
	"fmt"
)

// ประกาศตัวแปร age ด้วยคีย์เวิร์ด var ไว้ภายนอกฟังก์ชั่น main ซึ่งการประกาศแบบนี้ถูกต้อง
var age int = 18

func main() {
	// ประกาศตัวแปร name ด้วยคีย์เวิร์ด var ไว้ภายในฟังก์ชั่น main ซึ่งการประกาศแบบนี้ถูกต้อง
	var name string = "Orapin"
	fmt.Println("Hello World! ", name)
	fmt.Println("Your age is ", age)
}
