package main

import (
	"fmt"
)

func main() {
	var number int = 100
	var number2 int
	number2 = -200
	var number3 uint8 = 250
	number4 := 300

	fmt.Printf("Type of number1 is %T, value is %v\n", number, number)
	fmt.Printf("Type of number2 is %T, value is %v\n", number2, number2)
	fmt.Printf("Type of number3 is %T, value is %v\n", number3, number3)
	fmt.Printf("Type of number4 is %T, value is %v\n", number4, number4)
}