package main

import (
	"fmt"
)

func main() {
	// ประกาศตัวแปร name ด้วย := ไว้ภายในฟังก์ชั่น main ซึ่งการประกาศแบบนี้ถูกต้อง
	name := "Orapin"
	fmt.Println("Hello World! ", name)
}
