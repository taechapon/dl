package main

import (
	"fmt"
)

func main() {
	const PI = 3.14

	var circumference = 2 * PI * 2

	fmt.Println("circumference = ", circumference)
}
