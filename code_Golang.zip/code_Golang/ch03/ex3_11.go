package main

import (
	"fmt"
)

func main() {
	var num int
	var str string
	var b bool

	fmt.Println("Default value of numeric type is ", num)
	fmt.Println("Default value of string type is ", str)
	fmt.Println("Default value of bool type is ", b)
}
