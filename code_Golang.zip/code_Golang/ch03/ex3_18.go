package main

import (
	"fmt"
)

func main() {
	var bool_val1 bool
	bool_val2 := 1 < 2

	fmt.Printf("bool_val1 is %v\n", bool_val1)
	fmt.Printf("bool_val2 is %v\n", bool_val2)
}