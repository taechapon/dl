package main

import (
	"fmt"
)

func main() {
	s1 := "abcdefg"
	s2 := "Hêllò!"
	emoji := '😍'

	byte_s := []byte(s1)
	rune_s := []rune(s2)

	fmt.Printf("Type of %c is %T and value is %v\n", byte_s, byte_s, byte_s)
	fmt.Printf("Type of %c is %T and value is %v\n", rune_s, rune_s, rune_s)
	fmt.Printf("Type of %c is %T and value is %U\n", emoji, emoji, emoji)
}
