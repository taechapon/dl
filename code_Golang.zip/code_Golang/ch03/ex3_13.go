package main

import (
	"fmt"
)

func main() {
	var num1 int = 20
	num1 = 30

	num2 := 200
	num2 = 300

	fmt.Println("two number is ", num1, num2)
}
