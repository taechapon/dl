package main

import (
	"fmt"
)

func main() {
	const (
		TAX = 0.12
		VAT = 0.1
	)

	const PRODUCT_TAG = "Natural Perfume Blossom Limited Edition"
	const PRODUCT_QUANTITY = 2500
	TAX = 0.15

	fmt.Println("product tag = ", PRODUCT_TAG)
	fmt.Println("product quantity = ", PRODUCT_QUANTITY)
	fmt.Println("tax = ", TAX)
	fmt.Println("vat = ", VAT)
}
