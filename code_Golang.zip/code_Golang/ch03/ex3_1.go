package main

import (
	"fmt"
	"reflect"
)

func main() {
	str := "my number"
	num := 28
	status := true

	fmt.Println("type inference of str variable is ", reflect.TypeOf(str))
	fmt.Println("type inference of num variable is ", reflect.TypeOf(num))
	fmt.Println("type inference of status variable is ", reflect.TypeOf(status))
}
