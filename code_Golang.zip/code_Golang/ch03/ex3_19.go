package main

import (
	"fmt"
)

func main() {
	x := "\"hello golang\"\nI love golang programming"
	y := `"Hello golang" \n I love golang programming
Go Go Go I want to go`

	fmt.Println(x)
	fmt.Println()
	fmt.Println(y)
}