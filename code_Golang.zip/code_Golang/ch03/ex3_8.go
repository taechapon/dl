package main

import (
	"fmt"
)

var num int = 10

func main() {
	var num int = 20

	fmt.Println("my number is ", num)
}
