package main

import (
	"fmt"
)

type Person struct {
	name    string
	surname string
	age     int
}

func main() {
	var person1 = Person{"Manee", "Sodsai", 38}
	var person2 = Person{"Somsri", "Rakthai", 27}

	printPerson(&person1)
	printPerson(&person2)
}

func printPerson(p *Person) {
	fmt.Printf("Name : %s %s\n", p.name, p.surname)
	fmt.Printf("Age : %d\n\n", p.age)
}