package main

import (
	"encoding/json"
	"fmt"
)

type Employee struct {
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Age       int
}

func main() {
	json_string := `
    {
        "first_name": "Somsri",
        "last_name": "Rakdee",
        "Age": 23 
    }`

	emp1 := new(Employee)
	emp1.FirstName = "Fahsai"
	emp1.LastName = "Jaidee"
	emp1.Age = 35
	jsonStr, _ := json.Marshal(emp1)
	fmt.Printf("Encode struct to JSON : %s\n", jsonStr)

	emp2 := new(Employee)
	json.Unmarshal([]byte(json_string), emp2)
	fmt.Print("Decode JSON to struct : ")
	fmt.Println(emp2)
}