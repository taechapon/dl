package main

import (
	"fmt"
)

type Student struct {
	name  string
	age   int
	class string
}

func main() {
	var std1 Student
	var std2 Student

	// ข้อมูลนักเรียนคนที่ 1
	std1.name = "Manee"
	std1.age = 9
	std1.class = "Grade3"

	// ข้อมูลนักเรียนคนที่ 2
	std2.name = "Somsak"
	std2.age = 12
	std2.class = "Grade6"

	// พิมพ์ข้อมูลนักเรียนคนที่ 1
	fmt.Println("Student 1")
	printStudent(std1)

	// พิมพ์ข้อมูลนักเรียนคนที่ 2
	fmt.Println("Student 2")
	printStudent(std2)
}

func printStudent(std Student) {
	fmt.Println("Name: ", std.name)
	fmt.Println("Age: ", std.age)
	fmt.Println("Job: ", std.class)
	fmt.Println()
}
