package main

import (
	"fmt"
)

type Employee struct {
	name, surname, dept, position string
	salary                        float64
}

func main() {
	var emp1 Employee
	emp1.name = "Manee"
	emp1.surname = "Jaidee"

	emp2 := new(Employee)
	emp2.name = "Mana"
	emp2.surname = "Jaikla"

	var emp3 = &Employee{}
	emp3.name = "Mawin"
	(*emp3).surname = "Jairak"

	fmt.Println("Employee 1 : ", emp1)
	fmt.Println("Employee 2 : ", emp2)
	fmt.Println("Employee 3 : ", emp3)
}