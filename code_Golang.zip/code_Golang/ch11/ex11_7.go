package main

import (
	"fmt"
)

type Person struct {
	name    string
	surname string
	age     int
}

func main() {
	var person_var = Person{"Manee", "Sodsai", 38}

	var ptr_person *Person
	ptr_person = &person_var

	fmt.Println(ptr_person.name)
	fmt.Println(ptr_person.surname)
	fmt.Println((*ptr_person).age)
}
