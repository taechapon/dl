package main

import (
	"fmt"
)

type Employee struct {
	name, surname, dept, position string
	salary                        float64
}

func main() {
	emp1 := new(Employee)
	emp1.name = "Manee"
	emp1.surname = "Jaidee"
	emp1.dept = "HR"
	emp1.position = "HR Manager"
	emp1.salary = 55550

	fmt.Println("Employee Data is ", emp1)
}