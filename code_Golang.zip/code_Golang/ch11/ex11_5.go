package main

import (
	"fmt"
)

type Address struct {
	addr_num, street, district, province string
}

type Customer struct {
	cust_id, cust_fullname string
	cust_address           Address
}

func main() {
	cust := Customer{
		cust_id:       "c001",
		cust_fullname: "Somsak Rakdee",
		cust_address: Address{
			addr_num: "39/39",
			street:   "Vibhavadi Rangsit",
			district: "Chatuchak",
			province: "Bangkok"}}
	fmt.Println("Customer id : ", cust.cust_id)
	fmt.Println("Customer name : ", cust.cust_fullname)
	fmt.Println("Customer address : ", cust.cust_address)
}