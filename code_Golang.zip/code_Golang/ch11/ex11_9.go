package main

import (
    "fmt"
)

type Rectangle struct {
    length, width int
}

func (rec Rectangle) Area() int {
    return rec.length * rec.width
}

func printData(len int, wid int) {
    fmt.Printf("Length of rectangle is %d\n", len)
    fmt.Printf("Width of rectangle is %d\n", wid)
}

func main() {
    rec := Rectangle{30, 10}
    printData(rec.length, rec.width)
    fmt.Println("Area of Rectangle is ", rec.Area())
}