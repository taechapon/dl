package main

import (
	"fmt"
)

type Employee struct {
	name, surname, dept, position string
	salary                        float64
}

func main() {
	var emp = Employee{"Manee", "Sodsai", "HR", "HR Officer", 35000}

	fmt.Println("Employee Date : ")
	fmt.Println("Name : ", emp.name)
	fmt.Println("Surname : ", emp.surname)
	fmt.Println("Dept : ", emp.dept)
	fmt.Println("Position : ", emp.position)
	fmt.Println("Salary : ", emp.salary)
}