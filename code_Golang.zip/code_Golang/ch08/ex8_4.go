package main

import (
	"fmt"
)

func main() {
	original_array := [...]int{1, 2, 3, 4, 5}
	new_array := original_array

	fmt.Println("Before change value")
	fmt.Println("Original array :", original_array)
	fmt.Println("New array :", new_array)
	fmt.Println()

	new_array[0] = 10

	fmt.Println("After change new_array value")
	fmt.Println("Original array :", original_array)
	fmt.Println("New array :", new_array)
	fmt.Println()

	original_array[4] = 50

	fmt.Println("After change original_array value")
	fmt.Println("Original array :", original_array)
	fmt.Println("New array :", new_array)
	fmt.Println()
}