package main

import (
	"fmt"
)

func main() {
	var myarr1 = [...]string{"#1", "#2", "#3", "#4", "#5", "#6"}
	myarr2 := [...]string{"Golang", "C", "C++", "Python", "Java", "C#"}

	fmt.Println("Length of array myarr1 is ", len(myarr1))
	fmt.Println("Length of array myarr2 is ", len(myarr2))
	fmt.Println("Members of array myarr1 and myarr2 are : ")
	for i := 0; i < len(myarr1); i++ {
		fmt.Printf("%s : %s\n", myarr1[i], myarr2[i])
	}
}
