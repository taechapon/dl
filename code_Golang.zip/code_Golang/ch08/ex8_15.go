package main

import (
	"fmt"
)

func main() {
	slice1 := make([][]int, 2)
	fmt.Printf("slice1 length : %d\n", len(slice1))
	fmt.Printf("slice1 capacity : %d\n", cap(slice1))
	slice1[0] = []int{10, 20, 30, 40, 50}
	slice1[1] = []int{60, 70, 80, 90, 100}

	for x, row := range slice1 {
		for y, col := range row {
			fmt.Printf("slice1[%d][%d] : %v\n", x, y, col)
		}
	}

	slice2 := [][]string{{"AAA", "BBB"},
		{"CCC", "DDD"},
		{"EEE", "FFF"}}

	fmt.Println("Slice 2 : ", slice2)
}