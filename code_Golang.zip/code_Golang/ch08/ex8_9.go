package main

import (
	"fmt"
)

func main() {
	myarr := [6]string{"one", "two", "three", "four", "five", "six"}

	myslice := myarr[1:4]
	fmt.Printf("myslice = %v\n", myslice)
	fmt.Printf("length = %d\n", len(myslice))
	fmt.Printf("capacity = %d\n\n", cap(myslice))

	myslice2 := myarr[1:5]
	fmt.Printf("myslice2 = %v\n", myslice2)
	fmt.Printf("length = %d\n", len(myslice2))
	fmt.Printf("capacity = %d\n\n", cap(myslice2))

	myslice3 := myarr[0:6]
	fmt.Printf("myslice3 = %v\n", myslice3)
	fmt.Printf("length = %d\n", len(myslice3))
	fmt.Printf("capacity = %d\n\n", cap(myslice3))

	myslice4 := myarr[:2]
	fmt.Printf("myslice4 = %v\n", myslice4)
	fmt.Printf("length = %d\n", len(myslice4))
	fmt.Printf("capacity = %d\n\n", cap(myslice4))

	myslice5 := myarr[1:]
	fmt.Printf("myslice5 = %v\n", myslice5)
	fmt.Printf("length = %d\n", len(myslice5))
	fmt.Printf("capacity = %d\n\n", cap(myslice5))
}