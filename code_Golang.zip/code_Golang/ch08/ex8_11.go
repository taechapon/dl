package main

import (
	"fmt"
)

func main() {
	myslice := make([]int, 3, 10)
	myslice2 := make([]string, 2)

	myslice[0] = 1
	myslice[1] = 2
	myslice[2] = 3

	myslice2[0] = "Hi"
	myslice2[1] = "Hello"

	fmt.Printf("myslice (old) : %v\n", myslice)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(myslice), cap(myslice))

	fmt.Printf("myslice2 (old) : %v\n", myslice2)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(myslice2), cap(myslice2))

	newslice := append(myslice, 4, 5, 6)
	newslice2 := append(myslice2, "Hey")

	fmt.Printf("myslice (new) : %v\n", newslice)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(newslice), cap(newslice))

	fmt.Printf("myslice2 (new) : %v\n", newslice2)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(newslice2), cap(newslice2))
}