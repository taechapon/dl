package main

import (
	"fmt"
)

func main() {
	score := [5]int{80, 95, 75, 83, 78}
	std_name := [3]string{0: "Meena", 2: "Manee"}
	var grade [3]float32
	grade[0] = 3.03
	grade[1] = 2.80
	grade[2] = 3.90

	fmt.Println("score[5] = ", score)
	fmt.Printf("std_name[0] = %s\n", std_name[0])
	fmt.Printf("std_name[1] = %s\b\n", std_name[1])
	fmt.Printf("std_name[2] = %s\n", std_name[2])
	fmt.Println("grade[3] = ", grade)
}
