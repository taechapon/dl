package main

import (
	"fmt"
)

func main() {
	var myarr [2][2]int
	fmt.Println(myarr)
}