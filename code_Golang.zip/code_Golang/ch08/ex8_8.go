package main

import (
	"fmt"
)

func main() {
	myslice1 := []int{1, 2, 3}
	var myslice2 = []string{"Golang", "C", "Python", "Java", "C#"}
	var myslice3 []int
	myslice4 := []int{}

	fmt.Printf("Member of myslice1 : %v, length : %d\n", myslice1, len(myslice1))
	fmt.Printf("Member of myslice2 : %v, length : %d\n", myslice2, len(myslice2))
	fmt.Printf("Member of myslice3 : %v, length : %d\n", myslice3, len(myslice3))
	fmt.Printf("Member of myslice4 : %v, length : %d\n", myslice3, len(myslice4))

	fmt.Printf("Capacity of myslice1 : %d\n", cap(myslice1))
	fmt.Printf("Capacity of myslice2 : %d\n", cap(myslice2))
	fmt.Printf("Capacity of myslice3 : %d\n", cap(myslice3))
	fmt.Printf("Capacity of myslice4 : %d\n", cap(myslice4))

	fmt.Printf("Slice3 is Nil : %v\n", (myslice3 == nil))
	fmt.Printf("Slice4 is Nil : %v\n", (myslice4 == nil))
}
