package main

import (
	"fmt"
)

func main() {
	slice_number := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	fmt.Printf("slice = %v\n", slice_number)
	fmt.Printf("length = %d\n", len(slice_number))
	fmt.Printf("capacity = %d\n\n", cap(slice_number))

	filter_slice_number := slice_number[2:5]
	slice_number_copy := make([]int, len(filter_slice_number))

	copy(slice_number_copy, filter_slice_number)

	fmt.Printf("copy slice = %v\n", slice_number_copy)
	fmt.Printf("length = %d\n", len(slice_number_copy))
	fmt.Printf("capacity = %d\n", cap(slice_number_copy))
}