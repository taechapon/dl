package main

import (
	"fmt"
)

func main() {
	score := [5]int{80, 95, 75, 83, 78}

	fmt.Print("Student score : ")
	for i := 0; i < len(score); i++ {
		fmt.Print(score[i])
		fmt.Print(" ")
	}

	score[0] = 85
	score[4] = 80

	fmt.Printf("\nNew student score : ")
	for _, value := range score {
		fmt.Printf("%d ", value)
	}
}
