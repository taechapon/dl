package main

import (
	"fmt"
)

func main() {
	myslice := make([]int, 3, 10)
	myslice2 := make([]string, 2)

	myslice[0] = 1
	myslice[1] = 2
	myslice[2] = 3

	myslice2[0] = "Hi"
	myslice2[1] = "Hello"

	fmt.Println("myslice :", myslice)
	fmt.Printf("Length : %d\n", len(myslice))
	fmt.Printf("Capacity : %d\n\n", cap(myslice))

	fmt.Println("myslice2 :", myslice2)
	fmt.Printf("Length : %d\n", len(myslice2))
	fmt.Printf("Capacity : %d\n\n", cap(myslice2))
}
