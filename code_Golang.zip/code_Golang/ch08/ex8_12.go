package main

import (
	"fmt"
)

func main() {
	myslice := []int{10, 20, 30, 40}
	myslice2 := []int{50, 60, 70}

	fmt.Printf("myslice : %v\n", myslice)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(myslice), cap(myslice))

	fmt.Printf("myslice2: %v\n", myslice2)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(myslice2), cap(myslice2))

	newslice := append(myslice, myslice2...)

	fmt.Println("After append myslice2 to myslice")
	fmt.Printf("myslice (new) : %v\n", newslice)
	fmt.Printf("Length : %d, capacity : %d\n\n", len(newslice), cap(newslice))
}