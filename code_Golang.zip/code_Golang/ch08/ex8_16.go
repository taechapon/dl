package main

import (
	"fmt"
)

func main() {
	mymaps1 := make(map[string]int)
	mymaps1["A"] = 97
	mymaps1["B"] = 98
	mymaps1["C"] = 99

	mymaps2 := map[string]int{"Apple": 1, "Banana": 2, "Carrot": 3}

	mymaps3 := make(map[string]int)
	mymaps4 := map[string]bool{}
	var mymaps5 map[string]int

	fmt.Printf("mymaps1 = %v\n", mymaps1)
	fmt.Printf("mymaps2 = %v\n", mymaps2)
	fmt.Printf("mymaps3 = %v\n", mymaps3)
	fmt.Printf("mymaps4 = %v\n", mymaps4)
	fmt.Printf("mymaps5 = %v\n", mymaps5)
	fmt.Printf("mymaps3 is nil : %v\n", mymaps3 == nil)
	fmt.Printf("mymaps4 is nil : %v\n", mymaps4 == nil)
	fmt.Printf("mymaps5 is nil : %v\n", mymaps5 == nil)
	fmt.Printf("Member of key \"A\" in mymaps1 is : %v\n", mymaps1["A"])
	mymaps2["Apple"] = 10
	fmt.Printf("Members of mymaps2 are : %v\n", mymaps2)
	delete(mymaps1, "A")
	fmt.Printf("Member of key \"A\" in mymaps1 is : %v\n", mymaps1["A"])
}