package main

import (
	"fmt"
)

func main() {
	fruit := [3][2]string{{"banana", "mango"},
		{"apple", "strawberry"},
		{"kiwi", "apple"}}
	fmt.Println("List of fruits :")
	for x := 0; x < 3; x++ {
		for y := 0; y < 2; y++ {
			fmt.Printf("[%d][%d] : %s\n", x, y, fruit[x][y])
		}
		fmt.Println()
	}

	fruit[2][1] = "watermelon"
	fmt.Println("After change value of 2-dimension array :")
	for x := 0; x < 3; x++ {
		for y := 0; y < 2; y++ {
			fmt.Printf("[%d][%d] : %s\n", x, y, fruit[x][y])
		}
		fmt.Println()
	}
}
