package main

import (
	"fmt"
)

func main() {
	slice1 := []string{"This", "is", "Golang", "Programming"}

	fmt.Printf("First member of slice is \"%v\"\n", slice1[0])

	slice1[3] = "Language"

	fmt.Printf("Member of slice is %v\n", slice1)
}
