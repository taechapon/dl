package main

import "fmt"

type MyNum int

func (num1 MyNum) Plus(num2 MyNum) MyNum {
	return num1 + num2
}

func (num1 MyNum) Multiply(num2 MyNum) MyNum {
	return num1 * num2
}

func main() {
	n1 := MyNum(10)
	n2 := MyNum(20)
	fmt.Printf("%d + %d = %d\n", n1, n2, n1.Plus(n2))
	fmt.Printf("%d * %d = %d\n", n1, n2, n1.Multiply(n2))
}