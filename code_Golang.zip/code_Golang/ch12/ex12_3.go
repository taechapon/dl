package main

import "fmt"

type MyMethod struct {
	myvar int
}

func (m1 MyMethod) ValueRecv() {
	m1.myvar = m1.myvar * 10
}

func (m2 *MyMethod) PointerRecv() {
	m2.myvar = m2.myvar * 100
}

func main() {
	m := MyMethod{myvar: 5}
	fmt.Println("Call Value Receiver Method")
	fmt.Println("Original, myvar value is ", m.myvar)
	m.ValueRecv()
	fmt.Println("After call ValueRecv(), myvar value is ", m.myvar)
	fmt.Println()
	fmt.Println("Call Pointer Receiver Method")
	fmt.Println("Original, myvar value is ", m.myvar)
	m.PointerRecv()
	fmt.Println("After call PointerRecv(), myvar value is ", m.myvar)
}