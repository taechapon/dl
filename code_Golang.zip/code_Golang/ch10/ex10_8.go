package main

import (
	"fmt"
)

func myfunc(a *int, b *int) {
	*a = *a + 50
	*b = *b + 50
}

func main() {
	var num1 int = 100
	var num2 int = 200
	myfunc(&num1, &num2)
	fmt.Printf("First number is %d\n", num1)
	fmt.Printf("Second number is %d\n", num2)
}
