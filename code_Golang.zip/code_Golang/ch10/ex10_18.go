package main

import (
	"fmt"
)

func main() {
	fmt.Printf("Area is %d\n", func(w int, l int) int {
		return w * l
	}(3, 2))
}