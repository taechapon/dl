package main

import (
	"fmt"
)

func max_num(a int, b int) int {
	if a > b {
		return a
	} else {
		return b
	}
}

func main() {
	num1 := 15
	num2 := 30
	var max_value int
	max_value = max_num(num1, num2)
	fmt.Printf("Maximum number of %d and %d is %d\n", num1, num2, max_value)
}