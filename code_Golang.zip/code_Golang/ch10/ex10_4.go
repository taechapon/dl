package main

import (
	"fmt"
)

var result int

func multiply(a int, b int, c int) {
	result = a * b * c
	fmt.Printf("%d * %d * %d is %d\n", a, b, c, result)
}

func plus(a int, b int, c int) {
	result = a + b + c
	fmt.Printf("%d + %d + %d is %d\n", a, b, c, result)
}

func main() {
	num1 := 2
	num2 := 3
	num3 := 4
	multiply(num1, num2, num3)
	plus(num1, num2, num3)
}