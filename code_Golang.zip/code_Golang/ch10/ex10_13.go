package main

import (
	"fmt"
)

func changeSlice(slc []string) {
	slc = append(slc, "C#")
	fmt.Println("Slice from changeSlice func : ", slc)
}
func main() {
	slc := []string{"Python", "Scratch", "Java"}
	fmt.Println("Original Slice : ", slc)
	changeSlice(slc)
	fmt.Println("Lastest Slice : ", slc)
}
