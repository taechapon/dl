package main

import (
	"fmt"
)

func test_func(a int, b float32) {
	fmt.Printf("Integer value is %d\n", a)
	fmt.Printf("Float32 value is %.2f\n", b)
}

func main() {
	var a int = 10
	var num float32 = 20.5
	test_func(a, num)
}
