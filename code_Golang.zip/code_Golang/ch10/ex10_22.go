package main

import (
	"fmt"
)

func printQuestion(name string) {
	fmt.Println("Hello, what is your name?")
	fmt.Printf("%s", name)
}
func printAnswer(myfunc func(name string)) {
	myfunc("My name is Orapin")
}

func main() {
	printAnswer(printQuestion)
}
