package main

import (
	"fmt"
)

func printHeader() {
	fmt.Println("------------------------------------------------------")
	fmt.Println("Good food restaurant")
	fmt.Println("123/456 Kamphaeng Phet 3 Rd, Chatuchak, Bangkok 10900")
	fmt.Println("------------------------------------------------------")

}
func printFooter() {
	fmt.Println("------------------------------------------------------")
	fmt.Println("Thank you for dining with us")
	fmt.Println("------------------------------------------------------")
}

func main() {
	printHeader()
	fmt.Printf("Pizza\t259.00\n")
	fmt.Printf("Pasta\t125.00\n")
	fmt.Printf("Total\t384.00\n")
	printFooter()
}