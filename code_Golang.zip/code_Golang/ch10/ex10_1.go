package main

import (
	"fmt"
)

func printMenu() {
	fmt.Println("Menu")
	fmt.Println("##########")
	fmt.Println("1. Pasta")
	fmt.Println("2. Pizza")
	fmt.Println("3. Tuna Salad")
}

func main() {
	printMenu()
}