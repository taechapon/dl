package main

import (
	"fmt"
)

func printMsg() func() {
	return func() {
		fmt.Println("Goodbye, see you again")
	}
}

func main() {
	myfunc := printMsg()
	myfunc()
}