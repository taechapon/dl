package main

import (
	"fmt"
)

func countNum(num int) {
	fmt.Println(num)
	if num > 0 {
		countNum(num - 1)
	}
}
func main() {
	countNum(5)
}