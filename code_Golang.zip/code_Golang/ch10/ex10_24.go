package main

import (
	"fmt"
)

type sum_num func(int, int) int

func main() {
	var sn sum_num = func(a int, b int) int {
		return a + b
	}
	print(10, 20, sn)
}

func print(num1 int, num2 int, s sum_num) {
	fmt.Printf("%d + %d = %d", num1, num2, s(num1, num2))
}
