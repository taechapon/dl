package main

import (
	"fmt"
)

func getSum(arr [5]int) int {
	var i, sum int

	for i = 0; i < len(arr); i++ {
		sum += arr[i]
	}
	return sum
}

func main() {
	var myarr = [5]int{1, 2, 3, 4, 5}
	var sum int

	sum = getSum(myarr)

	fmt.Print("Summary of [")
	for i := 0; i < 5; i++ {
		fmt.Printf("%d ", myarr[i])
	}
	fmt.Printf("] is %d", sum)
}