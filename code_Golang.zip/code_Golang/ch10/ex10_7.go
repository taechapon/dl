package main

import (
	"fmt"
)

func myfunc() (fname string, lname string, age int) {
	fname = "John"
	lname = "Deeva"
	age = 32
	return
}

func main() {
	name1, name2, age := myfunc()
	fmt.Printf("Name : %s %s\n", name1, name2)
	fmt.Printf("Age : %d\n", age)
}