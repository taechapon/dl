package main

import (
	"fmt"
)

func mypets_arr(pets [3]string) {
	pets[0] = "Rabbit"
	fmt.Println("pets lists from mypets func : ", pets)
}

func mybooks_slc(books []string) {
	books[0] = "C"
	fmt.Println("book lists from mybooks func : ", books)
}

func main() {
	arr := [3]string{"Cat", "Dog", "Fish"}
	slc := []string{"Python", "Scratch", "Java"}

	fmt.Println("Original array : ", arr)
	mypets_arr(arr)
	fmt.Println("Lastest array :", arr)
	fmt.Println()
	fmt.Println("Original slice: ", slc)
	mybooks_slc(slc)
	fmt.Println("Lastest slice:", slc)
}
