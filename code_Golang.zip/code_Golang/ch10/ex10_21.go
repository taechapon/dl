package main

import (
	"fmt"
)

func printMsg(name string) {
	var greeting = func() {
		fmt.Printf("Hello, %s. How are you?", name)
	}
	greeting()
}
func main() {
	printMsg("Orapin")
}