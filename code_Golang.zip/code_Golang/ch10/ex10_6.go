package main

import (
	"fmt"
)

func cal(a, b int) (add int, minus int, mul int, div int) {
	add = a + b
	minus = a - b
	mul = a * b
	div = a / b
	return
}

func main() {
	a, b, c, d := cal(10, 5)

	fmt.Println("10 + 5 = ", a)
	fmt.Println("10 - 5 = ", b)
	fmt.Println("10 * 5 = ", c)
	fmt.Println("10 / 5 = ", d)
}
