package main

import (
	"fmt"
)

func main() {
	var area = func(w int, l int) int {
		return w * l
	}

	fmt.Printf("Area is %d\n", area(3, 2))
}