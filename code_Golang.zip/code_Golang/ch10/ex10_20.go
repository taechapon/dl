package main

import (
	"fmt"
)

func main() {
	weight := 2
	length := 3

	var area = func(w int, l int) int {
		return w * l
	}

	fmt.Printf("Area is %d\n", area(weight, length))
}