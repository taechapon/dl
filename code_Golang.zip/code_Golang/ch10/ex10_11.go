package main

import (
    "fmt"
)

func ArrFunc(myarr [5]int) [5]int {
    for i := 0; i < 5; i++ {
        myarr[i] = myarr[i] * 10
    }
    return myarr
}

func main() {
    arr := [5]int{10, 20, 30, 40, 50}
    var arr_return [5]int

    arr_return = ArrFunc(arr)

    fmt.Print("Array from ArrFunc : ")
    for i := 0; i < 5; i++ {
        fmt.Printf("%d ", arr_return[i])
    }
}
