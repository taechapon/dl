package main

import (
	"fmt"
)

func printAge() (*int, *string) {
	a := 28
	m := "Years Old"

	return &a, &m

}

func main() {
	result1, result2 := printAge()
	fmt.Println("I am", *result1, *result2)

}