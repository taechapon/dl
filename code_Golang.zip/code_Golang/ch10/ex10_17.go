package main

import (
	"fmt"
)

func main() {
	func(msg string) {
		fmt.Printf("Your message is \"%s\"\n", msg)
	}("Hello, how are you?")
}